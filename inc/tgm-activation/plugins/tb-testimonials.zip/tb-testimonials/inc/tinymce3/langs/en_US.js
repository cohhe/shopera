// English lang variables for WP2.5

tinyMCE.addI18n({en_US:{
tbtestimonials:{
desc : 'TBTestimonials - Add a testimonial to your post.'
}}});
