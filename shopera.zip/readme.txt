Shopera, Copyright 2015 Cohhe
Shopera is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/

Shopera is based on Underscores http://underscores.me/, (coffee) 2012-2014 Automattic, Inc.

Shopera bundles the following third-party resources:

Genericons icon font, Copyright 2013 Automattic
Genericons are licensed under the terms of the GNU GPL, Version 2.
Source: http://www.genericons.com

GLYPHICONS, Copyright 2010 - 2015 Jan Kovařík
GLYPHICONS is licensed under the GPLv3.0
Source: http://glyphicons.com

Bootstrap, Copyright 2015 Twitter
Bootstrap is released under the MIT license
Source: http://getbootstrap.com

HTML5 Shiv, Copyright 2014 Alexander Farkas (aFarkas)
HTML5 Shiv is licensed under GPL version 2
Source: https://github.com/aFarkas/html5shiv

jCarousel, Copyright 2006-2015 Jan Sorgalla
jCarousel is licensed under the MIT license
Source: http://sorgalla.com/jcarousel

Swiper, Copyright 2010-2014 Vladimir Kharlampidi
Swiper is licensed under GPL & MIT
Source: http://www.idangero.us/sliders/swiper/

Animate, Copyright 2014 Daniel Eden
Animate is licensed under the MIT license
Source: http://daneden.me/animate

Isotope, Copyright 2013 Metafizzy
Isotope is licensed under the GPLv3 license
Source: http://isotope.metafizzy.co

Used images in screenshot.png, licensed under CC0 Public Domain, free for commercial use / no attribution required
http://pixabay.com/en/aircraft-women-fashion-pilot-sky-428894/
http://pixabay.com/en/girls-model-woman-beauty-fashion-567778/
http://pixabay.com/en/city-urban-town-alley-stairs-427178/
http://pixabay.com/en/photography-fashion-women-design-459495/
http://pixabay.com/en/women-young-girl-beauty-bella-630033/
http://pixabay.com/en/man-glasses-hipster-beard-adult-597179/
http://pixabay.com/en/office-camera-creative-home-office-581122/