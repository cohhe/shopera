// German lang variables for WP2.5

tinyMCE.addI18n({de:{
tbtestimonials:{
desc : 'TBTestimonials - Add a testimonial to your post.'
}}});
